var hostname = window.location.hostname;
document.getElementById("title").innerHTML = hostname + " > login";

document.login.username.focus();

var infologin = document.getElementById("infologin");
infologin.innerHTML = "Masukkan Kode Voucher kemudian klik login.";

// login page 2 mode by Laksamadi Guko
var username = document.login.username;
var password = document.login.password;

username.placeholder = "Kode Voucher";

// set password = username
function setpass() {
  var user = username.value;
  //user = user.toLowerCase();
  username.value = user;
  password.value = user;
}

username.onkeyup = setpass;

// change to voucher mode
function voucher() {
  username.focus();
  username.onkeyup = setpass;
  username.placeholder = "Kode Voucher";
  username.style = "border-radius:10px;";
  password.type = "hidden";
  infologin.innerHTML = "Masukkan Kode Voucher kemudian klik login.";
}

// change to member mode
function member() {
  username.focus();
  username.onkeyup = "";
  username.placeholder = "Username";
  username.style = "border-radius:10px 10px 0px 0px;";
  password.type = "password";
  infologin.innerHTML = "Masukkan Username dan Password kemudian klik login.";
}
