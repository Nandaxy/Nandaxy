Vue.component("covid19", {
  data: function () {
    return { covid2: null };
  },
  created() {
    this.getData();
  },
  methods: {
    getData: function () {
      fetch("https://indonesia-covid-19.mathdro.id/api")
        .then((t) => t.json())
        .then((t) => {
          this.covid2 = t;
        });
    },
  },
  template:
    ' <table class="table"> <caption style="font-size: 16px; font-weight: bold; margin-bottom:5px;">Informasi Covid19 indonesia</caption> <tr> <th>Positif</th> <th>Sembuh</th> <th>Meninggal</th> </tr><tr v-if="covid2 !==null"> <td>{{covid2.jumlahKasus}}</td><td>{{covid2.sembuh}}</td><td>{{covid2.meninggal}}</td></tr></table>',
}),
  Vue.component("yhotie-ig-banner", {
    props: { username: String, header: String },
    data: function () {
      return { imgIgCollection: [] };
    },
    created() {
      this.getInstagaramPost();
    },
    methods: {
      getInstagaramPost: function () {
        fetch(`https://www.instagram.com/${this.username}/?__a=1`)
          .then((t) => t.json())
          .then(async (t) => {
            const { edge_owner_to_timeline_media: e } = await t.graphql.user;
            this.imgIgCollection = [...this.imgIgCollection, ...e.edges];
          })
          .then(() => {
            0 != this.imgIgCollection.length && this.getSlide();
          });
      },
      getSlide: function () {
        var t = 0;
        !(function e() {
          var i;
          var n = document.getElementsByClassName("mySlides");
          var a = document.getElementsByClassName("dot");
          for (i = 0; i < n.length; i++) n[i].style.display = "none";
          t++;
          t > n.length && (t = 1);
          for (i = 0; i < a.length; i++)
            a[i].className = a[i].className.replace(" active", "");
          n[t - 1].style.display = "block";
          a[t - 1].className += " active";
          setTimeout(e, 3e3);
        })();
      },
    },
    template:
      ' <div> <br/> <div style="font-size: 16px; font-weight: bold;   text-align: center; margin-bottom:5px;">{{header}}</div> <div class="slideshow-container"> <div v-for="(item, index) in imgIgCollection" :key="index" class="mySlides fade"> <div class="numbertext">{{index+1}}/{{imgIgCollection.length}}</div><img :src="item.node.display_url" style="width:100%"> </div></div><br/> <div style="text-align:center"> <span v-for="(item, index) in imgIgCollection" :key="index" class="dot"></span> <span class="dot"></span> </div></div>',
  });
